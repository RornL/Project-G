1.All shaders are created with amplify shader editor. Feel free to modify them.
2.You can preview all particles in "Particles" scene.
3.All particles are in prefabs folder.